module.exports = (app) => {
    var mainController = require('../controllers/mainController.js');

    app.get('/', mainController.home);
    app.get("/sendBulkMail", mainController.sendBulkMail);
}