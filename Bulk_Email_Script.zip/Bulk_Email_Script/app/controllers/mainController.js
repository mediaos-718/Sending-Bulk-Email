var fs = require('fs');
var nodemailer = require('nodemailer');
const delay = require('delay');

var transporter = nodemailer.createTransport({
    host: 'smtp.frontier.com',
    port: 465,
    secure: true,
    auth: {
        user: 'ssmkt@frontier.com',
        pass: 'Hayden1!'
    }
});



exports.home = function (req, res) {
    res.render("home");
}
exports.sendBulkMail = async function (req, res) {
    console.log("sendBulkMail");
    var filename = "public/list.txt";
    fs.readFile(filename, 'utf-8', async function (err, data) {
        if (err) throw err;
        console.log('OK: ' + filename);
        //console.log(data);
        var list = data.split("\n");
        //console.log(list);
        for (var i = 0; i < list.length; i++) {
            var cur_des_address = list[i];
            var from_address = generateSenderMailAddress() + "@frontier.com";
            console.log("Current from Address : " + from_address + "   and    Current des Address : " + cur_des_address);
            var mailOptions = {
                from: from_address,
                to: cur_des_address,
                subject: 'Sample email',
                text: 'That was test!'
            };
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log(error);
                } else {
                    console.log('Email sent: ' + info.response);
                }
            });
            await delay(1000);
        }
    })
    return res.json({
        status: 1
    });
}

function generateSenderMailAddress() {
    var str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    var random_str = "";
    for (i = 0; i < 14; i++) {
        var random_index = Math.floor(Math.random() * (str.length - 1));
        random_str += str.substr(random_index, 1);
    }
    return random_str;
}